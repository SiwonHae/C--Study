#include <stdio.h>

int main(void)
{
	char arr[50];
	int idx = 0;
	char temp;
	int i;

	printf("word : ");
	scanf_s("%s", arr, sizeof(arr) / sizeof(char));

	while (arr[idx] != '\0') // NULL�ձ��� �迭 ����.
		idx++;

	for (i = 0; i < idx / 2; i++)
	{
		temp = arr[i];
		arr[i] = arr[(idx - i) - 1];
		arr[(idx - i) - 1] = temp;
	}
	printf("reverse : %s\n", arr);

	return 0;
}