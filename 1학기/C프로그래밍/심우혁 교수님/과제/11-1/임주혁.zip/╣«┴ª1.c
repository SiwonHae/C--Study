#include <stdio.h>

int main(void)
{
	int arr[5];
	int i;
	int max, min, total;

	for (i = 0; i < 5; i++)
	{
		printf("���� �Է� : ");
		scanf_s("%d", &arr[i]);
	}
	max = min = total = arr[0];

	for (i = 1; i < 5; i++)
	{
		total += arr[i];
		if (max < arr[i])
			max = arr[i];
		if (min > arr[i])
			min = arr[i];
	}
	printf("�ִ밪 : %d, �ּҰ� : %d, �հ� : %d", max, min, total);


	return 0;
}