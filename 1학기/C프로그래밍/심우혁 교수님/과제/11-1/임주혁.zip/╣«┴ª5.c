#include <stdio.h>

int main(void)
{
	char phonenum1[50];
	char phonenum2[50];
	int idx = 0;
	int i, j;

	do
	{
		idx = 0;
		printf("��ȭ��ȣ �Է� : ");
		scanf_s("%s", phonenum1, sizeof(phonenum1) / sizeof(char));

		while (phonenum1[idx] != '\0') // NULL�ձ��� �迭 ����.
		{
			if (phonenum1[idx] < '0' || phonenum1[idx]>'9')
			{
				idx = 0;
				break;
			}
			idx++;
		}

		if (phonenum1[0] != '0' || phonenum1[1] != '1')
			idx = 0;

	} while (idx < 10 || idx > 11);

	if (idx == 11)
	{
		for (i = 0, j = 0; i <= 11; i++, j++)
		{
			if (i == 3 || i == 7)
				phonenum2[j++] = '-';
			phonenum2[j] = phonenum1[i];
		}
		phonenum2[13] = '\0';
		printf("%s", phonenum2);
	}

	if (idx == 10)
	{
		for (i = 0, j = 0; i <= 10; i++, j++)
		{
			if (i == 3 || i == 6)
				phonenum2[j++] = '-';
			phonenum2[j] = phonenum1[i];
		}
		phonenum2[12] = '\0';
		printf("%s", phonenum2);
	}

	return 0;
}