#include <stdio.h>

int main(void)
{
	char arr[50];
	int idx = 0;
	char max;
	int i;

	printf("word : ");
	scanf_s("%s", arr, sizeof(arr) / sizeof(char));

	while (arr[idx] != '\0') // NULL�ձ��� �迭 ����.
		idx++;
	max = arr[0];

	for (i = 1; i < idx; i++)
	{
		if (max < arr[i])
			max = arr[i];
	}

	printf("max : %c\n", max);

	return 0;
}