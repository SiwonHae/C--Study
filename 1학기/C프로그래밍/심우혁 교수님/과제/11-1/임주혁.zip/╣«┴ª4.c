#include <stdio.h>

int main(void)
{
	int arr[] = { 1,3,5,3,1 };
	int i;
	int star;

	for (i = 0; i < sizeof(arr) / sizeof(int); i++)
	{
		for (star = 1; star <= arr[i]; star++)
			printf("*");
		printf("\n");
	}

	return 0;
}