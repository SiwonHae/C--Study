#include <stdio.h>

void gugudan(int num1, int num2)
{
	while (num1 <= num2)
	{
		for (int i = 1; i <= 9; i++)
			printf("%d * %d = %d ", num1, i, num1 * i);
		printf("\n");
		num1++;
	}

}

int main(void)
{
	int num1, num2;
	printf("������ : ");
	scanf_s("%d %d", &num1, &num2);

	if (num1 < num2)
		gugudan(num1, num2);
	else
		gugudan(num2, num1);

	return 0;
}