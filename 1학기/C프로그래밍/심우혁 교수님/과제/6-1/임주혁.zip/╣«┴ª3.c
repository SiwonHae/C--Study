#include <stdio.h>
int main(void)
{

	printf("%-8s %8d %8d\n", "pen", 20, 100);
	printf("%-8s %8d %8d\n", "note", 5, 95);
	printf("%-8s %8d %8d\n", "eraser", 110, 97);
	return 0;
}