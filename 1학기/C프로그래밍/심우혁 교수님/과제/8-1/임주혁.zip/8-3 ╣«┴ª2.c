#include <stdio.h>
int main(void)
{
	int num;
	int sum = 0;

	while (1)
	{
		printf("num(0~100) : ");
		scanf_s("%d", &num);
		if (num == 0)
			break;
		if (num % 5 == 0)
			continue;
		sum += num;
	}
	printf("sum = %d", sum);

	return 0;
}