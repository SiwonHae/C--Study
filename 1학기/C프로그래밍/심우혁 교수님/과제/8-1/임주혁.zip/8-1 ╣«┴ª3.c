#include <stdio.h>
int main(void)
{
	int num1 = 0;
	int num2 = 0;
	int num3 = 0;
	double avg = 0;

	printf("���� ���� ���� ���� : ");
	scanf_s("%d %d %d", &num1, &num2, &num3);
	avg = (double)(num1 + num2 + num3) / 3;

	printf("average : %.2f\n", avg);

	if (avg >= 90)
		printf("grade : A\n");
	else if (avg >= 80)
		printf("grade : B\n");
	else if (avg >= 70)
		printf("grade : C\n");
	else if (avg >= 50)
		printf("grade : D\n");
	else
		printf("grade : F\n");

	return 0;
}