#include <stdio.h>

int main(void)
{
	char a[] = "alksdfkdsfqwejdksldfskl";
	int i = 0, count[26] = { 0 };
	printf("�Է� ���ڿ� : ");
	while (a[i] != '\0')
	{
		count[a[i] - 97] += 1;
		printf("%c", a[i]);
		i++;
	}
	printf("\n");

	printf("���ĺ� count \n");
	for (int j = 0; j < i - 1; j++)
		if (count[j] != 0)
			printf("%c\t%2d\n", j + 97, count[j]);

	return 0;
}

