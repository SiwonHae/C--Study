#include <stdio.h>

int main(void)
{
	char a[] = "Coronavirus Disease 2019 (COVID-19)";
	int i = 0, diff = 'a' - 'A';
	printf("%s \n", a);

	while (a[i] != '\0')
	{
		if (a[i] >= 'a' && a[i] <= 'z')
			a[i] = a[i] - diff;
		printf("%c", a[i]);
		i++;
	}
	printf("\n");


	return 0;
}