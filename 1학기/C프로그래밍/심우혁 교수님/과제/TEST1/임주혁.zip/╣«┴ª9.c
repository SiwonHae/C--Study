#include <stdio.h> 
int main(void)
{
	int num;
	int i = 1;
	int k = 1;
	int j = 1;
	int n = 1;

	printf("�� ��° �ױ��� ���ұ��? ");
	scanf_s("%d", &num);
	printf("0, ");

	for (i = 1; i <= num; i++)
	{
		if (i == 1 || i == 2)
		{
			n = 1;
		}
		else
		{
			k = j;
			j = n;
			n = k + j; // n + (n+1)
		}
		printf("%d, ", n);
	}
	return 0;
}