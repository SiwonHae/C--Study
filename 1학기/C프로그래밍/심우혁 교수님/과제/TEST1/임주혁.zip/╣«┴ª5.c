#include <stdio.h>
int main(void)
{
	int i, star, num;

	printf("���� �Է� : ");
	scanf_s("%d", &num);

	for (i = 1; i <= num; i++)
	{
		for (star = 1; star <= i; star++)
			printf("*");
		printf("\n");
	}

	return 0;
}