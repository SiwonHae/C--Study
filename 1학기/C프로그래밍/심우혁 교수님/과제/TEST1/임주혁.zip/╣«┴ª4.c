#include <stdio.h>
int main(void)
{
	double a = 3.32 * 1 / 10 * 1 / 10 * 1 / 10;
	double b = 9.76 * 1 / 10 * 1 / 10 * 1 / 10 * 1 / 10 * 1 / 10 * 1 / 10 * 1 / 10 * 1 / 10;
	printf("%e + %e = %f", a, b, a + b);
	return 0;
}