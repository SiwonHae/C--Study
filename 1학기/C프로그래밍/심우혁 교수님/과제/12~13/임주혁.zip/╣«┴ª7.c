#include <stdio.h>

int main(void)
{
	int arr1[10] = { 1, 3, 2, 4, 5, 7, 11, 2, 3, 9 };
	int arr2[10] = { 0 };

	int* fptr = &arr2[0];  // Ȧ��
	int* bptr = &arr2[9];  // ¦��
	int oddcount = 0;
	int evencount = 0;

	for (int i = 0; i < 10; i++)
	{
		if (arr1[i] % 2 == 0)
		{
			*bptr = arr1[i];
			bptr--;
			evencount++;
		}
		else
		{
			*fptr = arr1[i];
			fptr++;
			oddcount++;
		}
	}
	fptr = &arr2[0];
	bptr = &arr2[9];

	printf("Ȧ�� ��� : ");
	for (int i = 0; i < oddcount; i++)
	{
		printf("%d ", *fptr);
		fptr++;
	}
	printf("\n");

	printf("¦�� ��� : ");
	for (int i = 9; i >= oddcount; i--)
	{
		printf("%d ", *bptr);
		bptr--;
	}

	return 0;
}