#include <stdio.h>

int main(void)
{
	int arr[5] = { 45, 77, 89, 38, 93 };
	int* ptr = &arr[0];
	int arrsize = sizeof(arr) / sizeof(int);
	int i = 0;
	int sum = 0;

	while (i < arrsize)
	{
		sum += *ptr;
		i++;
		ptr++;
	}
	printf("sum = %d\n", sum);
	printf("average = %g\n", (double)sum / arrsize);

	return 0;
}