#include <stdio.h>

int main(void)
{
	int arr[] = { 3, 5, 10, 52, 1, 97, 36, 25, 13, 29 };
	int* ptr = &arr[0];
	int odd = 0;
	int even = 0;
	int arrnum = sizeof(arr) / sizeof(int);

	for (int i = 0; i < arrnum; i++)
	{
		if ((*ptr) % 2 == 0)
			even++;
		else
			odd++;
		ptr++;
	}

	printf("odd %d��\n", odd);
	printf("even %d��\n", even);

	return 0;
}