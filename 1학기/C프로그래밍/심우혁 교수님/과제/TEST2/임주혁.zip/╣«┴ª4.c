#include <stdio.h>
int main(void)
{
	char a[] = "alksdfkdsfqwejdksldfskl";
	int alen = 0;
	int count = 0;
	int sum = 0;

	while (a[alen] != '\0')
		alen++;

	printf("�Է� ���ڿ� : %s\n", a);
	printf("���ĺ�    count\n");

	for (int i = 'a'; i <= 'z'; i++)
	{
		for (int j = 0; j < alen; j++)
		{
			if (a[j] == i)
			{
				count++;
				sum += count;
				printf("%c            %d\n", a[j], sum);
			}
			count = 0;
			sum = 0;
		}
	}


	return 0;
}