#include <stdio.h>
int charge(int room, int person, int time)
{
	int i;
	int fee = 0;

	if (room == 1 && time == 1 && person == 3)
	{
		fee = 30000 + 5000;
		return fee;
	}

	if (room == 1 && time == 2 && person == 3)
	{
		fee = 50000 + 5000;
		return fee;
	}

	if (room == 1 && time == 2 && person <= 2)
	{
		fee = 50000;
		return fee;
	}

	if (room == 1 && time == 1 && person <= 2)
	{
		fee = 30000;
		return fee;
	}

	if (room == 2 && time == 1 && person == 5)
	{
		fee = 70000 + 10000;
		return fee;
	}
	if (room == 2 && time == 1 && person == 6)
	{
		fee = 70000 + 20000;
		return fee;
	}
	if (room == 2 && time == 1 && person == 7)
	{
		fee = 70000 + 30000;
		return fee;
	}

	if (room == 2 && time == 1 && person <= 4)
	{
		fee = 70000;
		return fee;
	}

	if (room == 2 && time == 2 && person == 5)
	{
		fee = 110000 + 10000;
		return fee;
	}
	if (room == 2 && time == 2 && person == 6)
	{
		fee = 110000 + 20000;
		return fee;
	}
	if (room == 2 && time == 2 && person == 7)
	{
		fee = 110000 + 30000;
		return fee;
	}
	if (room == 2 && time == 2 && person <= 4)
	{
		fee = 110000;
		return fee;
	}


	if (room == 3 && time == 1 && person == 9)
	{
		fee = 120000 + 15000;
		return fee;
	}
	if (room == 3 && time == 1 && person == 10)
	{
		fee = 120000 + 30000;
		return fee;
	}
	if (room == 3 && time == 1 && person == 11)
	{
		fee = 120000 + 45000;
		return fee;
	}
	if (room == 3 && time == 1 && person == 12)
	{
		fee = 120000 + 60000;
		return fee;
	}

	if (room == 3 && time == 1 && person <= 8)
	{
		fee = 120000;
		return fee;
	}

	if (room == 3 && time == 2 && person == 9)
	{
		fee = 170000 + 15000;
		return fee;
	}
	if (room == 3 && time == 2 && person == 10)
	{
		fee = 170000 + 30000;
		return fee;
	}
	if (room == 3 && time == 2 && person == 11)
	{
		fee = 170000 + 45000;
		return fee;
	}
	if (room == 3 && time == 2 && person == 12)
	{
		fee = 170000 + 60000;
		return fee;
	}

	if (room == 3 && time == 2 && person <= 8)
	{
		fee = 170000;
		return fee;
	}
}

int main(void)
{
	int room = 0;
	int person = 0;
	int time = 0;


	printf("�� ��ȣ(1~3) > ");
	scanf_s("%d", &room);
	printf("�ñ�(�����:1,������2) > ");
	scanf_s("%d", &time);

	if (room == 1)
	{
		do
		{
			printf("�ο��� > ");
			scanf_s("%d", &person);
		} while (person > 3);
	}
	if (room == 2)
	{
		do
		{
			printf("�ο��� > ");
			scanf_s("%d", &person);
		} while (person > 7);
	}
	if (room == 3)
	{
		do
		{
			printf("�ο��� > ");
			scanf_s("%d", &person);
		} while (person > 12);
	}

	printf("���ڿ�� : %d��", charge(room, person, time));


	return 0;
}