#include <stdio.h>
int num[9] = { 67, 89, 93, 55, 34, 98, 72, 80, 90 };

void print_data()
{
	for (int i = 0; i < 9; i++)
		printf("%d ", num[i]);
}

int get_Sum()
{
	int sum = 0;

	for (int i = 0; i < 9; i++)
		sum += num[i];

	return sum;
}

double get_Avg()
{
	int sum = 0;

	for (int i = 0; i < 9; i++)
		sum += num[i];

	return (double)sum / 9;
}

int get_Min()
{
	int min = 0;

	min = num[0];
	for (int i = 0; i < 9; i++)
		if (min > num[i])
			min = num[i];

	return min;
}

int get_Max()
{
	int max;

	max = num[0];
	for (int i = 0; i < 9; i++)
		if (max < num[i])
			max = num[i];

	return max;
}


int main(void)
{
	printf("( ");
	print_data();
	printf(")\n");

	printf("���� : %d��, ��� : %.1f��\n", get_Sum(), get_Avg());
	printf("�ְ� ���� : %d\n", get_Max());
	printf("���� ���� : %d\n", get_Min());

	return 0;
}