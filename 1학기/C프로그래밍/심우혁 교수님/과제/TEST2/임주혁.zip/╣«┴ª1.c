#include <stdio.h>
int main(void)
{
	char a[] = "Coronavirus Disease 2019 (COVID-19)";

	printf("%s\n", a);
	a[1] = 'O';
	a[2] = 'R';
	a[3] = 'O';
	a[4] = 'N';
	a[5] = 'A';
	a[6] = 'V';
	a[7] = 'I';
	a[8] = 'R';
	a[9] = 'U';
	a[10] = 'S';
	a[13] = 'I';
	a[14] = 'S';
	a[15] = 'E';
	a[16] = 'A';
	a[17] = 'S';
	a[18] = 'E';

	printf("%s\n", a);
	
	return 0;

}