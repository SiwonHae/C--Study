#include <stdio.h>
int Func(int num);

int main(void)
{
	int i;
	int num = 1;

	for (i = 2; num <= 10; i++)
	{
		if (Func(i) == 1)
		{
			printf("%d ", i);
			num++;
		}
	}

	return 0;
}

int Func(int num)
{
	int i;
	for (i = 2; i < num; i++)
	{
		if (num % i == 0)
			return i;
	}
	return 1;

}