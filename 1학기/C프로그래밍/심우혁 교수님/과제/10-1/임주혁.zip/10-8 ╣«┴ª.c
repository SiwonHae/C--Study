#include <stdio.h>
int Func(int num);

int main(void)
{
	int num;
	do
	{
		printf("���� �Է� : ");
		scanf_s("%d", &num);
	} while (num < 0);

	printf("2�� %d���� %d\n", num, Func(num));
	return 0;
}

int Func(int num)
{
	int result;

	if (num == 0)
		return 1;

	return 2 * Func(num - 1);
}