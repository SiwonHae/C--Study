#include <stdio.h> 
int main(void)
{
	int num, i;
	int a = 0;
	int b = 1;
	int c;

	printf("�� ��° �ױ��� ���ұ��? ");
	scanf_s("%d", &num);

	printf("%d, %d", a, b);
	for (i = 1; i < num; i++)
	{
		c = a + b;
		a = b;
		b = c;

		printf(", %d", c);
	}
	return 0;
}