#include <stdio.h>
int main(void)
{
	double a = 3.32e-3;
	double b = 9.76e-8;
	printf("%e + %e = %f", a, b, a + b);
	return 0;
}