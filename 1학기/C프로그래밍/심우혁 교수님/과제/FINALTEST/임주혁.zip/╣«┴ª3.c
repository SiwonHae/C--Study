#include <stdio.h>

void BubbleSort(int ary[], int len)
{
	int i, j;
	int temp;
	for (i = 0; i < len - 1; i++)
	{
		for (j = 0; j < (len - i) - 1; j++)
		{
			if (ary[j] > ary[j + 1])
			{
				temp = ary[j];
				ary[j] = ary[j + 1];
				ary[j + 1] = temp;
			}
		}
	}
}
int MergeSort(int arrA[], int arrB[], int arrC[])
{

}
int main(void)
{
	int A[5] = { 11, 5, 2, 7, 1 };
	int B[5] = { 3, 11, 13, 5, 9 };
	int C[10] = { 0 };
	BubbleSort(A, 5);
	BubbleSort(B, 5);
	int count = MergeSort(A, B, C);
	// count : MergeSort �ߺ� ���� ���Ҽ�
	// ��ºκ�
	return 0;
}