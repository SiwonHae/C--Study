#include <stdio.h>

int main(void)
{
    int A[7] = { 2, 11, 5, 7, 9, 15, 1 };
    int B[7] = { 13, 1, 5, 7, 13, 11, 3 };
    int C[7] = { 0 };
    int asize = sizeof(A) / sizeof(int);
    int bsize = sizeof(B) / sizeof(int);

    for (int i = 0; i < asize; i++)
        C[i] = A[i];

    for (int i = 0; i < asize; i++)
        for (int j = 0; j < bsize; j++)
            if (A[i] == B[j])
                C[i] = 1;

    printf("A - B = { ");
    for (int i = 0; i < asize; i++)
        if (C[i] != 1)
            printf("%d, ", C[i]);
    printf("}");

    return 0;
}