#include <stdio.h>
int tos = 0; // The Top of Stack (0���� ����)
int* parr; // The pointer of Stack (0���� ����)
int push(int p)
{
    if (p == 11)
        return 0;
    else
        return p - 1;
}
int pop()
{
    int check = 0;
    for (int i = 0; i < 10; i++)
        check++;
    if (check < 1)
        return 0;
}
int main(void)
{
    int arr[10] = { 1,2,3,4,5,6,7,8,9,10 };
    parr = arr;


    for (int i = 1; i < 12; i++)
    {
        if (push(i))
            printf("%d ", *(parr - 1)); // push() �� Ȯ��
        else
            printf("\n%d��° stack full\n", i); // ���� 0
    }


    for (int i = 10; i >= 0; i--)
    {
        if (pop())
            printf("%d ", *parr); // pop() �� Ȯ��
        else
            printf("\n%d��° stack empty\n", tos);
    } // ���� 0


    for (int i = 1; i <= 3; i++)
    {
        push(i * 10);
        printf("%d ", *(parr - 1)); // push() �� Ȯ��
    }

    return 0;
}