#include <stdio.h>

int main(void)
{
	char a[102];
	int asize = 0;
	int count = 0, sum = 0;

	printf("���ڿ� �Է�(1~99�����̳�) : ");
	scanf_s("%s", a, sizeof(a));
	while (a[asize] != '\0')
		asize++;

	for (int i = 0; i < asize; i++)
	{
		if (a[i] >= '0' && a[i] <= '9')
		{
			sum += a[i] - '0';
			count++;
		}

	}
	printf("sum : %d\n", sum);
	printf("avg : %g\n", (double)sum / count);

	return 0;
}