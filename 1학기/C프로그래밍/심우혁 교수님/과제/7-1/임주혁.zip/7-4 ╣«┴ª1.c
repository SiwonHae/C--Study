#include <stdio.h>
int main(void)
{
	int num1 = 0;
	int num2 = 0;
	int sum = 0;

	do
	{
		printf("���۰� �� ���� �Է� : ");
		scanf_s("%d %d", &num1, &num2);
	} while (num1 >= num2);

	for (sum = 0; num1 <= num2; num1++)
	{
		sum += num1;
	}

	printf("sum = %d", sum);
	return 0;
}