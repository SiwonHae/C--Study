#include <stdio.h>
int main(void)
{
	int num = 0;
	int star = 0;
	int circle = 0;

	printf("���� �Է� : ");
	scanf_s("%d", &num);

	while (star < num)
	{
		circle = 0;

		while (circle < star)
		{
			printf("o");
			circle++;
		}

		printf("*\n");
		star++;
	}
	return 0;
}