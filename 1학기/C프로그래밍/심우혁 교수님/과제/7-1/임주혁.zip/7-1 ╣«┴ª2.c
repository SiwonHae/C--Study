#include <stdio.h>
int main(void)
{
	int num = 0;
	int i = 0;

	printf("���� �Է� : ");
	scanf_s("%d", &num);

	while (i < num)
	{
		printf("%d ", 3 * (i + 1));
		i++;
	}
	return 0;
}