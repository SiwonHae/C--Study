#include <stdio.h>
int main(void)
{
	int num = 1;
	int sum = 0;

	while (num != 0)
	{
		printf("���� �Է� : ");
		scanf_s("%d", &num);
		sum += num;
	}

	printf("sum = %d\n", sum);

	return 0;
}