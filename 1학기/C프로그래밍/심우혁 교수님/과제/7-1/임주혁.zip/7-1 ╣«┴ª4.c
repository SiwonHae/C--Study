#include <stdio.h>
int main(void)
{
	int dan = 0;
	int num = 9;

	printf("�� ��? ");
	scanf_s("%d", &dan);

	while (num > 0)
	{
		printf("%d * %d = %d\n", dan, num, dan * num);
		num--;
	}
	return 0;
}