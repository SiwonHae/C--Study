#include <stdio.h>
int main(void)
{
	int i, num, factorial = 0;

	do
	{
		printf("���� �Է� : ");
		scanf_s("%d", &num);
	} while (num <= 0);

	printf("factorial = 1 ");

	for (i = 1; i < num; i++)
	{
		printf("* %d ", i + 1);
	}
	return 0;
}